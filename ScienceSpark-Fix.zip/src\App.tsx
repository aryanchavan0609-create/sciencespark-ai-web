 import React, { useState, useEffect, useRef } from "react";
import { Sparkles, MessageSquare, Globe, Settings, Send, Loader2 } from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import mermaid from "mermaid";

// Initialize the core diagram engine
mermaid.initialize({
  startOnLoad: true,
  theme: "dark",
  securityLevel: "loose",
  themeVariables: {
    background: "#020617",
    primaryColor: "#06b6d4",
    primaryTextColor: "#f8fafc",
    lineColor: "#334155"
  }
});

// 🔥 FIXED: Custom Safe Component to render actual vector blueprints live
const MermaidDiagram = ({ chart }: { chart: string }) => {
  const elementId = useRef(`mermaid-${Math.floor(Math.random() * 100000)}`);
  const [svg, setSvg] = useState<string>("");
  const [error, setError] = useState<boolean>(false);

  useEffect(() => {
    const renderChart = async () => {
      try {
        setError(false);
        // SURGICAL FIX: Remove potential syntax-breaking characters
        const sanitizedChart = chart
          .replace(/mermaid/g, "")
          .replace(/```/g, "")
          .trim();

        const { svg: renderedSvg } = await mermaid.render(elementId.current, sanitizedChart);
        setSvg(renderedSvg);
      } catch (err) {
        console.error("Mermaid parsing error:", err);
        setError(true);
      }
    };
    if (chart) {
      renderChart();
    }
  }, [chart]);

  if (error) {
    return (
      <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl text-xs font-mono text-cyan-400/70">
        ✨ Processing complex engineering schematic data matrix...
      </div>
    );
  }

  return <div className="my-6 p-4 bg-slate-950/80 border border-slate-800 rounded-xl overflow-x-auto flex justify-center shadow-2xl" dangerouslySetInnerHTML={{ __html: svg }} />;
};

export default function App() {
  const [query, setQuery] = useState("");
  const [language, setLanguage] = useState("ENG");
  const [archetype, setArchetype] = useState("ARCHETYPE_A");
  const [response, setResponse] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleQuerySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    setError(null);

    try {
     const res = await fetch("/api/query", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          query: query,
          language: language,
          archetype: archetype,
        }),
      });

      if (!res.ok) {
        throw new Error(`Server returned status ${res.status}`);
      }

      const data = await res.json();
      setResponse(data);
    } catch (err: any) {
      console.error("Query submit error:", err);
      setError(err.message || "Backend response error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-cyan-500 selection:text-slate-950">
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur sticky top-0 z-50 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-gradient-to-tr from-cyan-500 to-blue-600 p-2 rounded-xl shadow-lg shadow-cyan-500/20">
            <Sparkles className="w-6 h-6 text-slate-950 animate-pulse" />
          </div>
          <div>
            <h1 className="font-bold text-xl tracking-tight bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              ScienceSpark AI
            </h1>
            <p className="text-xs text-slate-400 font-medium">Core Intelligence Engine v2.5</p>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        <section className="lg:col-span-4 bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-6 h-fit backdrop-blur-sm">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
            <Settings className="w-4 h-4 text-cyan-400" />
            <h2 className="font-semibold text-sm tracking-wide text-slate-300 uppercase">Engine Profiles</h2>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-slate-500" /> Linguistic Tracking Track
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: "ENG", label: "English" },
                { id: "HIN-ENG", label: "Hinglish" },
                { id: "MAR", label: "मराठी" },
              ].map((lang) => (
                <button
                  key={lang.id}
                  type="button"
                  onClick={() => setLanguage(lang.id)}
                  className={`py-2 px-3 text-xs font-medium rounded-xl border transition-all duration-200 ${
                    language === lang.id
                      ? "bg-cyan-500/10 border-cyan-500 text-cyan-400 shadow-md shadow-cyan-500/5"
                      : "bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-300"
                  }`}
                >
                  {lang.label}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
              <MessageSquare className="w-3.5 h-3.5 text-slate-500" /> Intent Engine Archetype
            </label>
            <div className="space-y-2">
              {[
                { id: "ARCHETYPE_A", title: "Archetype A", desc: "Conceptual Exploratory (ELI5)" },
                { id: "ARCHETYPE_B", title: "Archetype B", desc: "Prototyping & Optimization" },
                { id: "ARCHETYPE_C", title: "Archetype C", desc: "Visual Workflow Request" },
              ].map((arch) => (
                <button
                  key={arch.id}
                  type="button"
                  onClick={() => setArchetype(arch.id)}
                  className={`w-full text-left p-3 rounded-xl border transition-all duration-200 block ${
                    archetype === arch.id
                      ? "bg-blue-500/10 border-blue-500 text-blue-400 shadow-md shadow-blue-500/5"
                      : "bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-300"
                  }`}
                >
                  <div className="text-xs font-bold uppercase tracking-wider">{arch.title}</div>
                  <div className="text-xs opacity-80 mt-0.5">{arch.desc}</div>
                </button>
              ))}
            </div>
          </div>
        </section>

        <section className="lg:col-span-8 flex flex-col space-y-6">
          <form onSubmit={handleQuerySubmit} className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 shadow-xl">
            <div className="flex gap-3">
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Ask about aerodynamics, thermal engine cycles, physics..."
                className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-cyan-500 placeholder:text-slate-600 text-slate-100 transition-colors"
                disabled={loading}
              />
              <button
                type="submit"
                disabled={loading || !query.trim()}
                className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-semibold px-5 rounded-xl transition-all shadow-md shadow-cyan-500/10 flex items-center gap-2 text-sm disabled:opacity-40 disabled:cursor-not-allowed group"
              >
                {loading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <span>Generate</span>
                    <Send className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
                  </>
                )}
              </button>
            </div>
          </form>

          <div className="flex-1 bg-slate-900/40 border border-slate-800 rounded-2xl p-6 min-h-[400px] flex flex-col shadow-inner backdrop-blur-sm relative overflow-hidden">
            {error && (
              <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 p-4 rounded-xl text-sm flex items-center gap-3">
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                <span><strong>Engine Mapping Failure:</strong> {error}</span>
              </div>
            )}

            {!response && !loading && !error && (
              <div className="my-auto text-center space-y-2 max-w-sm mx-auto opacity-40">
                <Sparkles className="w-8 h-8 mx-auto text-slate-500" />
                <p className="text-sm font-medium">Ready for Operational Command Input</p>
              </div>
            )}

            {loading && (
              <div className="my-auto text-center space-y-3">
                <Loader2 className="w-10 h-10 mx-auto text-cyan-400 animate-spin" />
                <p className="text-sm text-slate-400 font-medium tracking-wide animate-pulse">Running Intelligence Analysis Matrix...</p>
              </div>
            )}

            {response && !loading && (
              <div className="space-y-6 animate-fadeIn">
                <article className="prose prose-invert prose-cyan max-w-none text-slate-300 text-sm leading-relaxed space-y-4">
                  <ReactMarkdown 
                    remarkPlugins={[remarkGfm]}
                    components={{
                      code({ node, inline, className, children, ...props }: any) {
                        const match = /language-mermaid/.test(className || "");
                        return !inline && match ? (
                          <MermaidDiagram chart={String(children)} />
                        ) : (
                          <code className={className} {...props}>{children}</code>
                        );
                      }
                    }}
                  >
                    {response.response}
                  </ReactMarkdown>
                </article>
              </div>
            )}
          </div>
        </section>
      </main>
    </div>
  );
}